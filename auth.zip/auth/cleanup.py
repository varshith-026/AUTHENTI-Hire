import os
os.remove('backend/routes/interview_updated.py')
print('Cleaned up temporary file')
