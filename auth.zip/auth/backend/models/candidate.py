from dataclasses import dataclass

@dataclass
class Candidate:

    id: int = None
    name: str = ""
    email: str = ""
    photo_path: str = ""
    voice_path: str = ""

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "photo_path": self.photo_path,
            "voice_path": self.voice_path
        }