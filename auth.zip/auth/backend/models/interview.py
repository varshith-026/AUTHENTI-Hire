from dataclasses import dataclass

@dataclass
class Interview:

    id: int = None

    candidate_id: int = None

    risk_score: int = 0

    status: str = "SAFE"

    created_at: str = ""

    def to_dict(self):

        return {
            "id": self.id,
            "candidate_id": self.candidate_id,
            "risk_score": self.risk_score,
            "status": self.status,
            "created_at": self.created_at
        }