from dataclasses import dataclass

@dataclass
class Event:

    id: int = None

    interview_id: int = None

    event_type: str = ""

    confidence: float = 0.0

    timestamp: str = ""

    def to_dict(self):

        return {
            "id": self.id,
            "interview_id": self.interview_id,
            "event_type": self.event_type,
            "confidence": self.confidence,
            "timestamp": self.timestamp
        }