from dataclasses import dataclass

@dataclass
class Report:

    candidate_name: str = ""

    interview_id: int = None

    risk_score: int = 0

    status: str = ""

    recommendation: str = ""

    def to_dict(self):

        return {
            "candidate_name": self.candidate_name,
            "interview_id": self.interview_id,
            "risk_score": self.risk_score,
            "status": self.status,
            "recommendation": self.recommendation
        }