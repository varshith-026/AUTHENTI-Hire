from dataclasses import dataclass

@dataclass
class Interviewer:

    id: int = None
    name: str = ""
    email: str = ""
    company: str = ""

    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "company": self.company
        }