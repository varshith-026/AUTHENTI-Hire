import cv2


def initialize_camera():

    camera = cv2.VideoCapture(0)

    return camera


def capture_frame(camera):

    success, frame = camera.read()

    if success:
        return frame

    return None


def release_camera(camera):

    camera.release()