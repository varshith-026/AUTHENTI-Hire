# Risk Levels

SAFE = "SAFE"

SUSPICIOUS = "SUSPICIOUS"

HIGH_RISK = "HIGH_RISK"


# Eye Directions

CENTER = "center"

LEFT = "left"

RIGHT = "right"

DOWN = "down"


# Risk Thresholds

SAFE_THRESHOLD = 30

SUSPICIOUS_THRESHOLD = 60


# Supported File Types

ALLOWED_IMAGES = [
    "jpg",
    "jpeg",
    "png"
]

ALLOWED_AUDIO = [
    "wav",
    "mp3"
]