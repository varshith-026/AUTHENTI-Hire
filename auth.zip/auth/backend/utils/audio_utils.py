import wave


def get_audio_duration(filepath):

    try:

        with wave.open(filepath, "r") as audio:

            frames = audio.getnframes()

            rate = audio.getframerate()

            duration = frames / float(rate)

            return round(duration, 2)

    except Exception:

        return 0