import logging
import os

LOG_DIR = os.path.join(
    os.path.dirname(__file__),
    "..",
    "logs"
)

os.makedirs(LOG_DIR, exist_ok=True)

APP_LOG = os.path.join(LOG_DIR, "app.log")

INTERVIEW_LOG = os.path.join(
    LOG_DIR,
    "interview.log"
)


app_logger = logging.getLogger("app_logger")
app_logger.setLevel(logging.INFO)

app_handler = logging.FileHandler(APP_LOG)
app_handler.setFormatter(
    logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s"
    )
)

app_logger.addHandler(app_handler)


interview_logger = logging.getLogger(
    "interview_logger"
)

interview_logger.setLevel(logging.INFO)

interview_handler = logging.FileHandler(
    INTERVIEW_LOG
)

interview_handler.setFormatter(
    logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s"
    )
)

interview_logger.addHandler(
    interview_handler
)


def log_info(message):
    app_logger.info(message)


def log_error(message):
    app_logger.error(message)


def log_interview(message):
    interview_logger.info(message)