import os
from datetime import datetime


def generate_filename(prefix, extension):

    timestamp = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    return f"{prefix}_{timestamp}.{extension}"


def file_exists(path):

    return os.path.exists(path)


def success_response(data=None):

    return {
        "success": True,
        "data": data
    }


def error_response(message):

    return {
        "success": False,
        "error": message
    }