import sqlite3
import os

DB_PATH = os.path.join(
    os.path.dirname(__file__),
    "authentihire.db"
)


def create_database():

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # =========================
    # Candidates Table
    # =========================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS candidates(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        photo_path TEXT,
        voice_path TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # =========================
    # Interviewers Table
    # =========================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS interviewers(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE,
        company TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # =========================
    # Interviews Table
    # =========================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS interviews(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL,
        risk_score INTEGER DEFAULT 0,
        status TEXT DEFAULT 'SAFE',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(candidate_id)
        REFERENCES candidates(id)
    )
    """)

    # =========================
    # Events Table
    # =========================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS events(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        interview_id INTEGER,
        event_type TEXT,
        confidence REAL,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(interview_id)
        REFERENCES interviews(id)
    )
    """)

    # =========================
    # Reports Table
    # =========================
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS reports(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        interview_id INTEGER,
        candidate_name TEXT,
        risk_score INTEGER,
        status TEXT,
        recommendation TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY(interview_id)
        REFERENCES interviews(id)
    )
    """)

    conn.commit()
    conn.close()

    print("AuthentiHire Database Created Successfully")


if __name__ == "__main__":
    create_database()