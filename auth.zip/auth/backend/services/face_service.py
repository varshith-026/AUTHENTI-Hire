from ml_models.face_verification.deepface_model import verify_faces

def verify_face():

    return verify_faces(
        "uploads/photos/reference.jpg",
        "uploads/photos/current.jpg"
    )
import random

def verify_face():
    """
    Placeholder face verification.
    Replace with DeepFace.verify() later.
    """

    confidence = round(random.uniform(85, 99), 2)

    return {
        "verified": confidence > 90,
        "confidence": confidence
    }