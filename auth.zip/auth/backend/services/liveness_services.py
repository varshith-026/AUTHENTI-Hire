import random

def check_liveness():

    score = round(random.uniform(80, 100), 2)

    return {
        "live": score > 85,
        "score": score
    }