import random

def detect_ai_generated_answer(text):

    probability = round(
        random.uniform(10, 90),
        2
    )

    return {
        "ai_probability": probability,
        "flagged": probability > 70
    }