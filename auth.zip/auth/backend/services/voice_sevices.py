import random

def verify_voice():

    similarity = round(random.uniform(70, 100), 2)

    return {
        "voice_match": similarity > 85,
        "similarity": similarity
    }