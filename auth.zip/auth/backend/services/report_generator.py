def generate_report(
        candidate_name,
        risk_score,
        status
):

    return {
        "candidate": candidate_name,
        "risk_score": risk_score,
        "status": status,
        "recommendation":
            "Review Required"
            if risk_score > 30
            else
            "Approved"
    }