"""
backend.py — AuthentiHire consolidated backend
================================================
Combines:
  - config.py      → Section 1: Configuration
  - check_db.py    → Section 2: Database diagnostics (dev utility)
  - app.py         → Section 3: Flask application factory & entry point

Run:
    python backend.py              # start the server
    python backend.py --check-db   # inspect the SQLite database
"""

import os
import sys
import sqlite3
import argparse

# ---------------------------------------------------------------------------
# Section 1 · Configuration
# ---------------------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Ensure the project root is on the import path
ROOT_DIR = os.path.abspath(os.path.join(BASE_DIR, ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

DATABASE       = os.path.join(BASE_DIR, "database", "authentihire.db")
UPLOAD_FOLDER  = os.path.join(BASE_DIR, "uploads")
PHOTO_FOLDER   = os.path.join(UPLOAD_FOLDER, "photos")
VOICE_FOLDER   = os.path.join(UPLOAD_FOLDER, "voices")
RECORDING_FOLDER = os.path.join(UPLOAD_FOLDER, "recordings")

SECRET_KEY         = "authentihire_secret_key"
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "wav", "mp3"}


# ---------------------------------------------------------------------------
# Section 2 · Database diagnostics  (python backend.py --check-db)
# ---------------------------------------------------------------------------

def check_db(path: str = DATABASE) -> None:
    """Print basic diagnostics for the SQLite database at *path*."""
    print(f"Path   : {path}")
    print(f"Exists : {os.path.exists(path)}")

    if not os.path.exists(path):
        print("Database file not found — run the app first to initialise it.")
        return

    conn = sqlite3.connect(path)
    cursor = conn.cursor()

    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cursor.fetchall()
    print(f"Tables : {[t[0] for t in tables]}")

    if any(t[0] == "candidates" for t in tables):
        cursor.execute("PRAGMA table_info(candidates)")
        schema = cursor.fetchall()
        print("Candidates schema:")
        for col in schema:
            print(f"  {col}")

    conn.close()


# ---------------------------------------------------------------------------
# Section 3 · Flask application
# ---------------------------------------------------------------------------

def create_app() -> "Flask":
    from flask import Flask, send_from_directory
    from flask_cors import CORS

    from database.init_db import create_database
    from routes import router          # single consolidated blueprint

    frontend_dir = os.path.join(BASE_DIR, "..", "frontend")

    app = Flask(__name__)
    app.secret_key = SECRET_KEY
    app.config["UPLOAD_FOLDER"]   = UPLOAD_FOLDER
    app.config["DATABASE"]        = DATABASE

    CORS(app)
    create_database()

    # Register the single consolidated blueprint under /api
    app.register_blueprint(router, url_prefix="/api")

    # Serve the React / static frontend
    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve_frontend(path):
        target = os.path.join(frontend_dir, path)
        if path and os.path.exists(target):
            return send_from_directory(frontend_dir, path)
        return send_from_directory(frontend_dir, "index.html")

    return app


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="AuthentiHire backend")
    parser.add_argument(
        "--check-db",
        action="store_true",
        help="Print database diagnostics and exit",
    )
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--no-debug", action="store_true")
    args = parser.parse_args()

    if args.check_db:
        check_db()
        return

    app = create_app()
    app.run(host=args.host, port=args.port, debug=not args.no_debug)


if __name__ == "__main__":
    main()