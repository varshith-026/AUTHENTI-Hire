from flask import Blueprint, request, jsonify
import sqlite3
import os

auth_bp = Blueprint("auth", __name__)

DB_PATH = os.path.join(
    os.path.dirname(__file__),
    "..",
    "database",
    "authentihire.db"
)


@auth_bp.route("/login", methods=["POST"])
def login():

    data = request.json

    email = data.get("email")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    cursor.execute(
        "SELECT * FROM candidates WHERE email=?",
        (email,)
    )

    user = cursor.fetchone()

    conn.close()

    if user:
        return jsonify({
            "success": True,
            "message": "Login Successful"
        })

    return jsonify({
        "success": False,
        "message": "User Not Found"
    }), 404