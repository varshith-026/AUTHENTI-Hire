from flask import Blueprint, jsonify
import sqlite3
import os

analytics_bp = Blueprint("analytics", __name__)

DB_PATH = os.path.join(
    os.path.dirname(__file__),
    "..",
    "database",
    "authentihire.db"
)


@analytics_bp.route("/analytics")
def analytics():

    conn = sqlite3.connect(DB_PATH)

    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM candidates
        """
    )

    total_candidates = cursor.fetchone()[0]

    cursor.execute(
        """
        SELECT COUNT(*)
        FROM interviews
        """
    )

    total_interviews = cursor.fetchone()[0]

    conn.close()

    return jsonify({
        "total_candidates": total_candidates,
        "total_interviews": total_interviews
    })