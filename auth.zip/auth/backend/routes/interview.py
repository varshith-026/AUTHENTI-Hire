from flask import Blueprint, request, jsonify

from services.eye_tracking import detect_eye_movement
from services.liveness_services import check_liveness
from services.risk_engine import calculate_risk
from services.ai_voice_detector import detect_ai_voice, analyze_voice_quality

interview_bp = Blueprint("interview", __name__)


@interview_bp.route("/analyze-frame", methods=["POST"])
def analyze_frame():

    eye = detect_eye_movement()

    live = check_liveness()

    risk = calculate_risk(
        eye,
        live
    )

    return jsonify({
        "success": True,
        "eye_tracking": eye,
        "liveness": live,
        "risk_score": risk
    })


@interview_bp.route("/detect-ai-voice", methods=["POST"])
def detect_voice_authenticity():
    """
    Analyzes audio to detect if it's AI-generated or human speech.
    """
    try:
        # Get audio file from request if provided
        audio_file = request.files.get('audio')
        audio_path = None
        
        if audio_file:
            # Save uploaded audio temporarily
            audio_path = f"uploads/voices/{audio_file.filename}"
            audio_file.save(audio_path)
        
        # Perform AI voice detection
        voice_detection = detect_ai_voice(audio_path)
        
        # Analyze voice quality
        voice_quality = analyze_voice_quality(audio_path)
        
        return jsonify({
            "success": True,
            "voice_detection": voice_detection,
            "voice_quality": voice_quality
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500