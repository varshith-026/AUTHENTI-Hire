from backend.services.liveness_service import check_liveness


def test_liveness():

    result = check_liveness()

    assert isinstance(result, dict)

    assert "live" in result

    assert "score" in result

    print("Liveness Detection Test Passed")


if __name__ == "__main__":
    test_liveness()