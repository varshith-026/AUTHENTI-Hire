import requests

BASE_URL = "http://localhost:5000/api"


def test_register():

    payload = {
        "name": "Test User",
        "email": "test@example.com"
    }

    response = requests.post(
        f"{BASE_URL}/register",
        json=payload
    )

    print(
        "Register API:",
        response.status_code
    )


def test_login():

    payload = {
        "email": "test@example.com"
    }

    response = requests.post(
        f"{BASE_URL}/login",
        json=payload
    )

    print(
        "Login API:",
        response.status_code
    )


def test_dashboard():

    response = requests.get(
        f"{BASE_URL}/dashboard"
    )

    print(
        "Dashboard API:",
        response.status_code
    )


if __name__ == "__main__":

    test_register()

    test_login()

    test_dashboard()