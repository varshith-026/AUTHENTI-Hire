from backend.services.face_service import verify_face


def test_face_verification():

    result = verify_face()

    assert isinstance(result, dict)

    assert "verified" in result

    assert "confidence" in result

    print("Face Verification Test Passed")


if __name__ == "__main__":
    test_face_verification()