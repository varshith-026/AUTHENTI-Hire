from backend.services.risk_engine import (
    calculate_risk,
    classify_risk
)


def test_risk_engine():

    eye_result = {
        "suspicious": True
    }

    liveness_result = {
        "live": False
    }

    risk_score = calculate_risk(
        eye_result,
        liveness_result
    )

    status = classify_risk(
        risk_score
    )

    assert risk_score >= 0

    assert status in [
        "SAFE",
        "SUSPICIOUS",
        "HIGH_RISK"
    ]

    print("Risk Engine Test Passed")


if __name__ == "__main__":
    test_risk_engine()