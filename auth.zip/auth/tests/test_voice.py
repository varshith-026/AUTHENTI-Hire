from backend.services.voice_service import verify_voice


def test_voice_verification():

    result = verify_voice()

    assert isinstance(result, dict)

    assert "voice_match" in result

    assert "similarity" in result

    print("Voice Verification Test Passed")


if __name__ == "__main__":
    test_voice_verification()