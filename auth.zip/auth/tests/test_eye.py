from backend.services.eye_tracking import detect_eye_movement


def test_eye_tracking():

    result = detect_eye_movement()

    assert isinstance(result, dict)

    assert "direction" in result

    assert "suspicious" in result

    print("Eye Tracking Test Passed")


if __name__ == "__main__":
    test_eye_tracking()