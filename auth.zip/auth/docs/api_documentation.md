# AuthentiHire API Documentation

## Base URL

http://localhost:5000/api

---

# Authentication APIs

## Register Candidate

Endpoint:

POST /register

Request:

```json
{
  "name": "John Doe",
  "email": "john@example.com"
}
```

Response:

```json
{
  "success": true,
  "candidate_id": 1
}
```

---

## Login

Endpoint:

POST /login

Request:

```json
{
  "email": "john@example.com"
}
```

Response:

```json
{
  "success": true,
  "message": "Login Successful"
}
```

---

# Interview APIs

## Analyze Frame

Endpoint:

POST /analyze-frame

Response:

```json
{
  "eye_tracking": {
    "direction": "center",
    "suspicious": false
  },
  "liveness": {
    "live": true,
    "score": 98
  },
  "risk_score": 15,
  "risk_status": "SAFE"
}
```

---

# Dashboard APIs

## Dashboard

Endpoint:

GET /dashboard

Response:

```json
[
  {
    "id": 1,
    "name": "John Doe",
    "email": "john@example.com"
  }
]
```

---

# Reports APIs

## Get Report

Endpoint:

GET /report/<id>

Response:

```json
{
  "candidate_name": "John Doe",
  "risk_score": 25,
  "status": "SAFE",
  "recommendation": "Proceed"
}
```

---

# Analytics APIs

## Analytics Summary

Endpoint:

GET /analytics

Response:

```json
{
  "total_interviews": 120,
  "safe": 100,
  "suspicious": 15,
  "high_risk": 5
}
```

---

# Risk Score Levels

SAFE

0 - 30

SUSPICIOUS

31 - 60

HIGH_RISK

61 - 100

---

# Technologies Used

Backend
- Flask
- SQLite
- OpenCV
- DeepFace
- Whisper

Frontend
- HTML
- CSS
- JavaScript

AI Models
- Face Verification
- Eye Tracking
- Voice Verification
- Liveness Detection
- AI Answer Detection