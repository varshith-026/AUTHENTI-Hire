import random

def detect_ai_answer(text):

    probability = round(
        random.uniform(0, 100),
        2
    )

    return {
        "ai_probability": probability,
        "flagged": probability > 70
    }