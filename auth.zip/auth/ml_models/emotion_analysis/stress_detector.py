import random

def detect_stress():

    stress = random.randint(
        0,
        100
    )

    return {
        "stress_score": stress,
        "high_stress": stress > 70
    }