import random

def detect_gaze():

    directions = [
        "center",
        "left",
        "right",
        "down"
    ]

    return random.choice(directions)