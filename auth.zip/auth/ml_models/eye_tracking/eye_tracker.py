import cv2

def track_eyes(frame):

    return {
        "status": "tracking",
        "frame_received": frame is not None
    }