import random

def detect_blink():

    return {
        "blink_detected":
        random.choice(
            [True, False]
        )
    }